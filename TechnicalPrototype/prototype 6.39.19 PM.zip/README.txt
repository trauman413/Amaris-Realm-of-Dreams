Controls:
---------
-Left and Right Arrow Keys: Move the player left and right, respectively.
-Up Arrow Key: Jump
-Left Shift Key (when the player has at least one fountain in the ability queue): Activate the first fountain ability's timer. From there, you have 300 ms to use the ability. 
-Space Bar: Activate the special ability except for transparency which is always active while the timer is on.