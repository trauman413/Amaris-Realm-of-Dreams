Controls:
---------
-Left and Right Arrow Keys (or A and D): Move the player left and right, respectively.
-Up Arrow Key (or W): Jump.
-Left Shift Key (when the player has passed through a fountain first): Activate the ability's timer. From there, you have 300 ms to use the ability.
-Space Bar: Use the ability if activated.
