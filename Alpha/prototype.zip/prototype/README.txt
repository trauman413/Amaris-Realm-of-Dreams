Controls:
---------
-Left and Right Arrow Keys: Move the player left and right, respectively.
-Up Arrow Key: Jump
-Shift Key (when the player has passed through a fountain first): Activate that 
ability's timer. From there, you have 300 ms to use the ability.
-Space Bar: Activate the special ability