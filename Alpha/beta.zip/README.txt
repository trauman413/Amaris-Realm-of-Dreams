Controls:
---------
-Left and Right Arrow Keys (or A and D): Move the player left and right, respectively. 
-Up Arrow Key (or W): Jump. 
-Space Bar (when the player has passed through a fountain first): Activate the ability's timer. From there, you have 5 seconds to use the ability. 
-Double Tap Up Arrow Key (or W): Flight (if flight ability activated). 
-Double Tap Left and Right Arrow Keys (or A and D): Dash (is dash ability activated). 
- M key: map mode. 
- P key: pause.
- R key: restart.